/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemareservas;

/**
 *
 * @author ferna
 */
public class Reserva {

    private String cedula;
    private String fechaComida;
    private String tipoComida;
    private String guarnicion1;
    private String guarnicion2;
    private String proteina;
    private String ensalada;

    public Reserva(String cedula, String fechaComida, String tipoComida, String guarnicion1, String guarnicion2, String proteina, String ensalada) {
        this.cedula = cedula;
        this.fechaComida = fechaComida;
        this.tipoComida = tipoComida;
        this.guarnicion1 = guarnicion1;
        this.guarnicion2 = guarnicion2;
        this.proteina = proteina;
        this.ensalada = ensalada;
    }

    public String toString() {
        return cedula + "\n"
                + "Fecha de comida: " + fechaComida + "\n"
                + "Tipo de comida: " + tipoComida + "\n"
                + "Guarnicion 1: " + guarnicion1 + "\n"
                + "Guarnicion 2: " + guarnicion2 + "\n"
                + "Proteina: " + proteina + "\n"
                + "Ensalada: " + ensalada + "\n";
    }
}
