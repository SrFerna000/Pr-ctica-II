/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.sistemareservas;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author ferna
 */
public class SistemaReservas {

    private static final String USUARIOS_FILE = "usuarios.txt";
    private static final String RESERVAS_FILE = "reservas.txt";

    private List<Reserva> reservas = new ArrayList<>();

    public static void main(String[] args) {
        SistemaReservas sistema = new SistemaReservas();
        sistema.iniciar();
    }

    public void iniciar() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Menú:");
            System.out.println("1. Agregar usuario");
            System.out.println("2. Agregar reserva");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Esto limpia el buffer de entrada

            switch (opcion) {
                case 1:
                    agregarUsuario();
                    break;
                case 2:
                    agregarReserva();
                    break;
                case 3:
                    guardarReservas();
                    return;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
        }
    }

    private void agregarUsuario() {
        Scanner scanner = new Scanner(System.in);
        try (PrintWriter writer = new PrintWriter(new FileWriter(USUARIOS_FILE, true))) {
            while (true) {
                System.out.print("Ingrese cédula (o 'q' para salir): ");
                String cedula = scanner.nextLine();
                if (cedula.equals("q")) {
                    break;
                }
                System.out.print("Ingrese nombre: ");
                String nombre = scanner.nextLine();
                System.out.print("Ingrese número telefónico: ");
                String telefono = scanner.nextLine();
                writer.println(cedula + "," + nombre + "," + telefono);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private synchronized void agregarReserva() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el número de cédula del usuario: ");
        String cedula = scanner.nextLine();

        if (!usuarioExiste(cedula)) {
            System.out.println("El usuario no existe. No se puede realizar la reserva.");
            return;
        }

        System.out.print("Fecha de comida (DD/MM/YYYY): ");
        String fechaComida = scanner.nextLine();
        System.out.print("Tipo de comida (Desayuno/Almuerzo/Cena): ");
        String tipoComida = scanner.nextLine();
        System.out.print("Guarnicion 1 (Arroz/Frijoles/Pancakes/Frutas): ");
        String guarnicion1 = scanner.nextLine();
        System.out.print("Guarnicion 2 (Arroz/Frijoles/Pancakes/Frutas): ");
        String guarnicion2 = scanner.nextLine();
        System.out.print("Proteína (Carne/Pescado/Pollo/Huevos): ");
        String proteina = scanner.nextLine();
        System.out.print("Ensalada (Verde/Rusa): ");
        String ensalada = scanner.nextLine();

        Reserva reserva = new Reserva(cedula, fechaComida, tipoComida, guarnicion1, guarnicion2, proteina, ensalada);
        reservas.add(reserva);
    }

    private synchronized void guardarReservas() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(RESERVAS_FILE))) {
            for (Reserva reserva : reservas) {
                writer.println(reserva.toString());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private boolean usuarioExiste(String cedula) {
        try (BufferedReader reader = new BufferedReader(new FileReader(USUARIOS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 1 && parts[0].equals(cedula)) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }
}
